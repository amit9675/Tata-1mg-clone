import logo from './logo.svg';
import './App.css';
//import Filter from './components/Filter';
//import MainRoutes from './pages/MainRoutes';
import Medicines from './pages/Medicines';




function App() {
  return (
    <div className="App">
      

      
      <Medicines/>
     
    </div>
  );
}

export default App;
